"""
File Loader Utility
Handles loading files with correct priority for executable vs script environments
When running as executable, prioritizes user data directory over bundled files
"""

import os
import sys
import shutil


def get_app_directories():
    """
    Returns the base directories for the application
    """
    if getattr(sys, 'frozen', False):
        # Running as executable
        bundled_dir = sys._MEIPASS
        user_data_dir = os.path.join(os.path.expanduser("~"), "FreemanSchoolPortal")
        os.makedirs(user_data_dir, exist_ok=True)
    else:
        # Running as script
        bundled_dir = os.path.dirname(os.path.realpath(__file__))
        user_data_dir = bundled_dir
    
    return bundled_dir, user_data_dir


def get_file_path(relative_path, prefer_user_data=True):
    """
    Get the full path to a file with correct priority
    
    Args:
        relative_path: Relative path from base directory (e.g., "ui_dashboard.py")
        prefer_user_data: If True, prioritize user data directory when running as executable
    
    Returns:
        Full path to the file
    """
    bundled_dir, user_data_dir = get_app_directories()
    
    if getattr(sys, 'frozen', False) and prefer_user_data:
        # For executable, check user data directory first
        user_path = os.path.join(user_data_dir, relative_path)
        if os.path.exists(user_path):
            return user_path
        
        # Fall back to bundled directory
        bundled_path = os.path.join(bundled_dir, relative_path)
        if os.path.exists(bundled_path):
            return bundled_path
    else:
        # For script or when preferring bundled, use bundled directory
        bundled_path = os.path.join(bundled_dir, relative_path)
        if os.path.exists(bundled_path):
            return bundled_path
    
    # If not found, return the user data path (for new files from updates)
    return os.path.join(user_data_dir, relative_path)


def initialize_user_data_files():
    """
    Copy essential files from bundled directory to user data directory
    This should be called on first run or when needed
    """
    bundled_dir, user_data_dir = get_app_directories()
    
    if not getattr(sys, 'frozen', False):
        return  # Not needed for script mode
    
    # Files to copy to user data directory
    files_to_copy = [
        'update_config.json',
        'version.json',
        'school_config.json',
        'notification_config.json',
        'mpesa_config.json'
    ]
    
    for filename in files_to_copy:
        bundled_path = os.path.join(bundled_dir, filename)
        user_path = os.path.join(user_data_dir, filename)
        
        if not os.path.exists(user_path) and os.path.exists(bundled_path):
            try:
                shutil.copy2(bundled_path, user_path)
                print(f"[FileLoader] Copied {filename} to user data directory")
            except Exception as e:
                print(f"[FileLoader] Failed to copy {filename}: {e}")


def get_updated_module_path(module_name):
    """
    Get the path to a Python module, prioritizing updated versions in user data
    
    Args:
        module_name: Name of the module (e.g., "ui_dashboard")
    
    Returns:
        Path to the module file
    """
    # Try .py file
    py_path = get_file_path(f"{module_name}.py")
    if os.path.exists(py_path):
        return py_path
    
    # Try compiled version if needed
    return None


def sync_updated_files():
    """
    Ensure updated files from user data directory are available
    This can be called after an update to ensure files are in the right place
    """
    bundled_dir, user_data_dir = get_app_directories()
    
    if not getattr(sys, 'frozen', False):
        return  # Not needed for script mode
    
    # This is mainly for informational purposes
    # The actual file loading is handled by get_file_path
    print(f"[FileLoader] Bundled dir: {bundled_dir}")
    print(f"[FileLoader] User data dir: {user_data_dir}")
